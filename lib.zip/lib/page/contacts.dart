import 'package:flutter/material.dart';

class ContactsPage extends StatelessWidget {
  static const route = '/contacts';
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        appBar: new AppBar(
          title: new Text("Contacts"),
          centerTitle: true,
          backgroundColor: Color.fromARGB(137, 59, 55, 55),
        ),
        body: new ContactList(kContacts));
  }
}

const kContacts = const <Contact>[
  const Contact(
      fullName: 'M.Rifki Yohandy', email: 'rifkiyohandy2002@gmail.com'),
  const Contact(fullName: 'Aufa Rizky', email: 'Aufarizky@gmail.com'),
  const Contact(fullName: 'Thurzi Hamdani', email: 'Thurzihamdani@gmail.com'),
];

class ContactList extends StatelessWidget {
  final List<Contact> _contacts;

  ContactList(this._contacts);

  @override
  Widget build(BuildContext context) {
    return new ListView.builder(
      padding: new EdgeInsets.symmetric(vertical: 8.0),
      itemBuilder: (context, index) {
        return new _ContactListItem(_contacts[index]);
      },
      itemCount: _contacts.length,
    );
  }
}

class _ContactListItem extends ListTile {
  _ContactListItem(Contact contact)
      : super(
            title: new Text(
              contact.fullName,
              style: TextStyle(color: Colors.white),
            ),
            subtitle: new Text(
              contact.email,
              style: TextStyle(color: Colors.white),
            ),
            leading: new CircleAvatar(child: new Text(contact.fullName[0])));
}

class Contact {
  final String fullName;
  final String email;

  const Contact({required this.fullName, required this.email});
}
