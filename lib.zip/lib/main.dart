import 'package:flutter/material.dart';
import 'package:kegiatan_1/home.dart';
import 'package:kegiatan_1/page/contacts.dart';
import 'package:kegiatan_1/page/login.dart';
import 'package:kegiatan_1/page/meet&chat.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
          primarySwatch: Colors.blue,
          scaffoldBackgroundColor: Color.fromARGB(255, 46, 46, 49)),
      //home: Home(),
      initialRoute: '/login',
      routes: {
        '/': (_) => Home(),
        '/login': (_) => Login(),
        ContactsPage.route: (_) => ContactsPage(),
        Meet_Chat.route: (_) => Meet_Chat()
      },
    );
  }
}
